#pragma once

#include "../defines.hpp"

namespace NCrashReporter {
    void createAndSaveCrash(int sig);
};