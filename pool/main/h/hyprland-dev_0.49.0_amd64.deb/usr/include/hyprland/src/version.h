#pragma once
#define GIT_COMMIT_HASH    "9958d297641b5c84dcff93f9039d80a5ad37ab00"
#define GIT_BRANCH         ""
#define GIT_COMMIT_MESSAGE "    version: bump to 0.49.0"
#define GIT_COMMIT_DATE    "Thu May 8 20:15:18 2025"
#define GIT_DIRTY          ""
#define GIT_TAG            "v0.49.0"
#define GIT_COMMITS        "1"
