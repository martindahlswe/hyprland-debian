#pragma once
#include <map>
static const std::map<std::string, std::string> SHADERS = {
{"CM.frag",
#include "./CM.frag.inc"
},
{"CM.glsl",
#include "./CM.glsl.inc"
},
{"blur1.frag",
#include "./blur1.frag.inc"
},
{"blur2.frag",
#include "./blur2.frag.inc"
},
{"blurfinish.frag",
#include "./blurfinish.frag.inc"
},
{"blurfinish_legacy.frag",
#include "./blurfinish_legacy.frag.inc"
},
{"blurprepare.frag",
#include "./blurprepare.frag.inc"
},
{"blurprepare_legacy.frag",
#include "./blurprepare_legacy.frag.inc"
},
{"border.frag",
#include "./border.frag.inc"
},
{"border_legacy.frag",
#include "./border_legacy.frag.inc"
},
{"ext.frag",
#include "./ext.frag.inc"
},
{"glitch.frag",
#include "./glitch.frag.inc"
},
{"passthru.frag",
#include "./passthru.frag.inc"
},
{"quad.frag",
#include "./quad.frag.inc"
},
{"rgba.frag",
#include "./rgba.frag.inc"
},
{"rgbamatte.frag",
#include "./rgbamatte.frag.inc"
},
{"rgbx.frag",
#include "./rgbx.frag.inc"
},
{"rounding.glsl",
#include "./rounding.glsl.inc"
},
{"shadow.frag",
#include "./shadow.frag.inc"
},
{"shadow_legacy.frag",
#include "./shadow_legacy.frag.inc"
},
{"tex.vert",
#include "./tex.vert.inc"
},
{"tex300.vert",
#include "./tex300.vert.inc"
},
{"tex320.vert",
#include "./tex320.vert.inc"
},
};
