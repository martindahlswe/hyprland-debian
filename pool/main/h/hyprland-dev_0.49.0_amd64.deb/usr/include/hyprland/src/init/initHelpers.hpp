#pragma once

#include "../defines.hpp"

namespace NInit {
    bool isSudo();
    void gainRealTime();
};