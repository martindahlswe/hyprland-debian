// Glaze Library
// For the license information refer to glaze.hpp

#pragma once

#include "glaze/toml/write.hpp"
