// Glaze Library
// For the license information refer to glaze.hpp

#pragma once

#if defined GLZ_ENABLE_EETF

#include "glaze/eetf/read.hpp"
#include "glaze/eetf/write.hpp"

#endif
