#pragma once

#ifndef HT_HIDDEN
#define HT_HIDDEN private
#endif
