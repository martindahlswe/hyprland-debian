#pragma once

#include <cstdint>

namespace Hyprtoolkit {
    enum ePointerShape : uint8_t {
        HT_POINTER_ARROW = 0,
        HT_POINTER_POINTER,
        HT_POINTER_TEXT,
    };
}